const wallieLogo = require("../assets/images/wallie-logo.png");
const banner = require("../assets/images/banner.png");
const promoBanner = require("../assets/images/promo-banner.png");
const focus = require("../assets/images/focus.png");

// Dummy
const usFlag = require("../assets/images/us-flag.jpg");


export default {
    wallieLogo,
    banner,
    promoBanner,
    focus,

    // Dummy
    usFlag
}